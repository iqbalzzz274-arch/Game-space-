package com.redmia3.gamespace;

import android.app.*;
import android.os.*;
import android.provider.Settings;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, stats;
    TextView status;

    int dp(float n){ return (int)(n*getResources().getDisplayMetrics().density+0.5f); }

    TextView tv(String s, float size, int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(2),dp(2),dp(2),dp(2)); return t;
    }

    Button btn(String label){
        Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setTextSize(15); b.setAllCaps(false); b.setBackgroundResource(com.redmia3.gamespace.R.drawable.button_bg);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(56)); p.setMargins(0,dp(8),0,dp(8));
        b.setLayoutParams(p); return b;
    }

    public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,8,18));
        build();
    }

    void build(){
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20),dp(18),dp(20),dp(24)); root.setBackgroundColor(Color.rgb(7,8,18));
        scroll.addView(root);

        TextView title=tv("GAME SPACE",28,Color.WHITE); title.setTypeface(null,1);
        root.addView(title);
        TextView sub=tv("REDMI A3  •  PREMIUM GAMING MODE",12,Color.rgb(167,163,184));
        root.addView(sub);

        LinearLayout hero=new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20),dp(24),dp(20),dp(20)); hero.setBackgroundResource(R.drawable.card_bg);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(220)); hp.setMargins(0,dp(22),0,dp(14)); hero.setLayoutParams(hp);
        TextView max=tv("PERFORMANCE",13,Color.rgb(167,163,184)); hero.addView(max);
        TextView big=tv("MAX",46,Color.rgb(168,85,247)); big.setTypeface(null,1); hero.addView(big);
        TextView cpu=tv("CPU  •  up to 2.20 GHz",16,Color.WHITE); hero.addView(cpu);
        TextView device=tv("IMG PowerVR GE8320  •  90 Hz display",13,Color.rgb(167,163,184)); hero.addView(device);
        root.addView(hero);

        Button start=btn("▶  START GAMING");
        start.setOnClickListener(v -> startGaming());
        root.addView(start);

        status=tv("Ready — root not required",13,Color.rgb(167,163,184));
        status.setGravity(Gravity.CENTER); root.addView(status);

        TextView h=tv("QUICK CONTROLS",18,Color.WHITE); h.setTypeface(null,1);
        h.setPadding(0,dp(18),0,dp(8)); root.addView(h);

        Button performance=btn("⚡  Fixed Performance Mode");
        performance.setOnClickListener(v -> fixedPerformance());
        root.addView(performance);

        Button power=btn("🔋  Disable Power Saver");
        power.setOnClickListener(v -> powerNormal());
        root.addView(power);

        Button display=btn("🖥️  Open Display / Refresh Rate");
        display.setOnClickListener(v -> open(Settings.ACTION_DISPLAY_SETTINGS));
        root.addView(display);

        Button battery=btn("🔕  Open Do Not Disturb");
        battery.setOnClickListener(v -> open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
        root.addView(battery);

        TextView info=tv("SAFE MODE\nCommands that require privileged shell/root are not executed by the APK. Use Brevent/Shizuku separately if you have them.",13,Color.rgb(167,163,184));
        info.setPadding(0,dp(20),0,dp(20)); root.addView(info);

        setContentView(scroll);
    }

    void startGaming(){
        boolean a=fixedPerformance();
        boolean c=powerNormal();
        status.setText((a||c) ? "Gaming profile applied where Android allows it." : "Gaming profile ready.");
    }

    boolean fixedPerformance(){
        try{
            Process p=Runtime.getRuntime().exec(new String[]{"cmd","power","set-fixed-performance-mode-enabled","true"});
            int code=p.waitFor();
            status.setText(code==0 ? "Fixed Performance: ON" : "Fixed Performance unavailable without privileged shell.");
            return code==0;
        }catch(Exception e){
            status.setText("Fixed Performance needs Brevent/Shizuku/root shell access.");
            return false;
        }
    }

    boolean powerNormal(){
        try{
            Process p=Runtime.getRuntime().exec(new String[]{"cmd","power","set-mode","0"});
            int code=p.waitFor();
            return code==0;
        }catch(Exception e){ return false; }
    }

    void open(String action){
        try{ startActivity(new Intent(action)); }catch(Exception e){}
    }
}
