# Game Space Redmi A3 Premium

Native Android Game Space UI designed for Redmi A3.

Features:
- Premium dark/neon gaming dashboard
- Start Gaming button
- Fixed Performance Mode attempt
- Disable power saver attempt
- Display/refresh-rate settings shortcut
- Do Not Disturb shortcut
- No root required for installation

Important:
A normal APK cannot bypass Android shell permissions. Commands such as
`cmd power set-fixed-performance-mode-enabled` may require privileged shell
access (for example via Brevent/Shizuku/root) on the device. The app fails
gracefully instead of pretending a tweak worked.

Build:
GitHub Actions -> Build Game Space Redmi A3 -> download GameSpace-RedmiA3-debug.
